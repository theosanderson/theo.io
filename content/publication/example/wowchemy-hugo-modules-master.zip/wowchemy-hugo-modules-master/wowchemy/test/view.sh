hugo server -p 1330 --minify --templateMetrics --templateMetricsHints
